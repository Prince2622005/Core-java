// W.A.J.P to check whether a given string starts with the contents of another string.
// Red is favorite color. Starts with Red? True Orange is also my favorite color. Starts
// with Red? False I3. 
public class eighteen 
{
    public static void main(String[] args) 
    {
        String string1 = "Red is favorite color.";
        String prefix1 = "Red";
        boolean result1 = startsWithContents(string1, prefix1);
        System.out.println("\"" + string1 + "\" Starts with \"" + prefix1 + "\"? " + result1);

        String string2 = "Orange is also my favorite color.";
        String prefix2 = "Red";
        boolean result2 = startsWithContents(string2, prefix2);
        System.out.println("\"" + string2 + "\" Starts with \"" + prefix2 + "\"? " + result2);
    }

    public static boolean startsWithContents(String mainString, String prefix) {
        return mainString.startsWith(prefix);
    }
}
