// B19. Write a program in Java to display the first 10 natural numbers
// using while loop
public class four {
    public static void main(String[] args) {

        // (while Loop)
        int count = 1;
        while (count <= 10) {
            System.out.println(count);
            count++;

            // (for Loop)
            // int count;
            // for (int i = 1; i <= 10; i++) {
            // System.out.println(i);

            // (do while Loop)
            // int count = 1;
            // do
            // {
            // System.out.println(count);
            // count++;
            // }while(count<=10);
        }
    }
}

// }
