public class sixteen 
{
    public static void main(String[] args) 
    {
        String s1 = "topsint.com";
        String s2 = "topsint.com";
        String s3 = "Topsint.com";

        boolean isequal1 = s1.equals(s2);
        System.out.println("Comparing topsint.com and topsint.com: " + isequal1);

        // boolean isequal2 = s1.equalsIgnoreCase(s3); - to ignore the capital letters but with same name
         boolean isequal2 = s1.equals(s3);
        System.out.println("Comparing topsint.com and Topsint.com: " + isequal2);

    }
}