import java.util.ArrayList;
import java.util.List;

public class nineteen {

    public static List<String> findInterleavings(String str1, String str2) {
        List<String> interleavings = new ArrayList<>();
        findInterleavingsHelper("", str1, str2, interleavings);
        return interleavings;
    }

    private static void findInterleavingsHelper(String prefix, String remaining1, String remaining2,
            List<String> interleavings) {
        if (remaining1.isEmpty() && remaining2.isEmpty()) {
            interleavings.add(prefix);
            return;
        }

        if (!remaining1.isEmpty()) {
            findInterleavingsHelper(prefix + remaining1.charAt(0), remaining1.substring(1), remaining2, interleavings);
        }

        if (!remaining2.isEmpty()) {
            findInterleavingsHelper(prefix + remaining2.charAt(0), remaining1, remaining2.substring(1), interleavings);
        }
    }

    public static void main(String[] args) {
        String str1 = "WX";
        String str2 = "YZ";
        List<String> result = findInterleavings(str1, str2);

        System.out.println("Interleavings of " + str1 + " and " + str2 + ":");
        for (String interleaving : result) {
            System.out.println(interleaving);
        }
    }
}
