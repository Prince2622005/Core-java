import java.util.Scanner;

public class two {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a single character: ");
        String input = scanner.nextLine();

        // Check if the input is a single character
        if (input.length() == 1) {
            char character = input.charAt(0);

            // Check if the input is a letter
            if (Character.isLetter(character)) {
                // Convert the character to uppercase for easier comparison
                character = Character.toUpperCase(character);

                // Check if the character is a vowel
                if (character == 'A' || character == 'E' || character == 'I' || character == 'O' || character == 'U') {
                    System.out.println("Vowel");
                } else {
                    System.out.println("Consonant");
                }
            } else {
                System.out.println("Error: Input is not a letter.");
            }
        } else {
            System.out.println("Error: Input is not a single character.");
        }

        scanner.close();
    }
}
