
// Java Program to print pattern
// Number-changing pyramid
import java.util.*;

// Java code for printing pattern
public class seventh {
    public static void main(String[] args) {
        int k = 1;
        for (int i = 1; i <= 4; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print(k++);
                System.out.print("");
            }
            System.out.println();
        }

    }
    // Function to demonstrate pattern
}