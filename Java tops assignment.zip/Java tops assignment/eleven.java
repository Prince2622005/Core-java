import java.util.Scanner;

public class eleven {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter an integer (n): ");
        int n = scanner.nextInt();

        int result = n + (n * (n * n)) + (n * (n * n * n));

        System.out.println("Result: " + result);

        scanner.close();
    }
}
