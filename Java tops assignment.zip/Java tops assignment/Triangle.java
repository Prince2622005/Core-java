
public class Triangle {

    public double calculatePerimeter() {
        return 0;
    }

    public double calculateArea() {
        return 0;
    }

}
