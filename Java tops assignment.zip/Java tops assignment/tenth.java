import java.util.Scanner;

public class tenth {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        char charac = sc.next().charAt(0);
        int asciival = (int) charac;// Cast the character to an integer to get its ASCII value
        System.out.println("Ascii val: " + asciival);

    }
}