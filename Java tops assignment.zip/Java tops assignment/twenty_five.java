// • Create a class with a method that prints "This is a parent class" and its subclass with
// another method that prints "This is child class". Now, create an object for each of
// the class and call 1 - method of parent class by object of parent class 2 - method of
// child class by object of child class 3 - method of parent class by object of child class 
class Parent {
    public void parentmethod() {
        System.out.println("This is parent class");
    }
}

class Child extends Parent {
    public void childmethod() {
        System.out.println("This is Child class");
    }
}

public class twenty_five {
    public static void main(String[] args) {
        Parent ob = new Parent();
        ob.parentmethod();

        Child ob1 = new Child();
        ob1.childmethod();

        ob1.parentmethod();

    }
}