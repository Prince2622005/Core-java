// Create a class to print the area of a square and a rectangle. The class has two methods
// with the same name but different number of parameters. The method for printing
// area of a rectangle has two parameters which are length and breadth respectively
// while the other method for printing area of square has one parameter which is side
// of square. 
class area {
    public void method1(double length, double breadth) // this is our method 1 - rectangle
    {
        System.out.println("Area of rectangle: " + length * breadth);
    }

    public void method1(float side) // this is our method 1 - square
    {
        System.out.println("Area of square: " + side * side);

    }

}

public class twenty_four {
    public static void main(String[] args) {
        area a = new area();
        a.method1(5, 4);
        a.method1(5);

    }

}
