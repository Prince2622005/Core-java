public class fourteen {
    public static void main(String[] args) {
        String originalString = "Tops Technologies!";

        int index1 = 0;
        int index2 = 10;

        char charAtindex1 = originalString.charAt(index1);
        char charAtindex2 = originalString.charAt(index2);

        System.out.println("Original String: " + originalString);
        System.out.println("Char at position " + index1 + " is: " + charAtindex1);
        System.out.println("Char at position " + index2 + " is: " + charAtindex2);

    }
}