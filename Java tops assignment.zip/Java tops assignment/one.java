import java.util.Scanner;

public class one {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a;
        System.out.println("Enter value a : ");
        a = sc.nextInt();
        int b;
        System.out.println("Enter value b : ");
        b = sc.nextInt();
        int c;
        System.out.println("Enter value c : ");
        c = sc.nextInt();
        if (a > b && a > c) {
            System.out.println("A is greatest");
        } else if (b > a && b > c) {
            System.out.println("B is greatest");
        } else {
            System.out.println("C is greatest");
        }

    }
}