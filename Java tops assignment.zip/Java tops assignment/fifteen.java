public class fifteen {
    public static void main(String[] args) {
        String firstname = "Hello,";
        String lastname = "World!";

        String concateString = firstname + lastname;
        // System.out.println("Concated string: " + concateString);
        System.out.println("Concated String: " + firstname.concat(lastname));

    }
}