public class seventeen 
{
    public static void main(String[] args) 
    {
        String str1 = "Java Exercises";
        String str2 = "se";
        String str3 = "Java Exercise";

        // Check if str1 ends with the contents of str2
        boolean endsWith1 = str1.endsWith(str2);
        System.out.println("\"Java Exercises\" ends with \"se\"? " + endsWith1);

        // Check if str3 ends with the contents of str2
        boolean endsWith2 = str3.endsWith(str2);
        System.out.println("\"Java Exercise\" ends with \"se\"? " + endsWith2);
    }
}
