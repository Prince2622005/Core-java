// • Print the sum, difference and product of two complex numbers by creating a class
// named 'Complex' with separate methods for each operation whose real and
// imaginary parts are entered by user

import java.util.Scanner;

class Complex {
    private double real;
    private double imaginary;

    // Constructor to initialize complex numbers
    public Complex(double real, double imaginary) {
        this.real = real;
        this.imaginary = imaginary;
    }

    // Method to add two complex numbers
    public Complex add(Complex other) {
        double newReal = this.real + other.real;
        double newImaginary = this.imaginary + other.imaginary;
        return new Complex(newReal, newImaginary);
    }

    // Method to subtract two complex numbers
    public Complex subtract(Complex other) {
        double newReal = this.real - other.real;
        double newImaginary = this.imaginary - other.imaginary;
        return new Complex(newReal, newImaginary);
    }

    // Method to multiply two complex numbers
    public Complex multiply(Complex other) {
        double newReal = (this.real * other.real) - (this.imaginary * other.imaginary);
        double newImaginary = (this.real * other.imaginary) + (this.imaginary * other.real);
        return new Complex(newReal, newImaginary);
    }

    // Method to display the complex number
    public void display() {
        System.out.println(this.real + " + " + this.imaginary + "i");
    }
}

public class twenty_nine {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the real and imaginary parts of the first complex number:");
        double real1 = scanner.nextDouble();
        double imaginary1 = scanner.nextDouble();

        System.out.println("Enter the real and imaginary parts of the second complex number:");
        double real2 = scanner.nextDouble();
        double imaginary2 = scanner.nextDouble();

        Complex complex1 = new Complex(real1, imaginary1);
        Complex complex2 = new Complex(real2, imaginary2);

        // Perform operations and display results
        System.out.println("Sum of the complex numbers:");
        Complex sum = complex1.add(complex2);
        sum.display();

        System.out.println("Difference of the complex numbers:");
        Complex difference = complex1.subtract(complex2);
        difference.display();

        System.out.println("Product of the complex numbers:");
        Complex product = complex1.multiply(complex2);
        product.display();

        scanner.close();
    }
}
