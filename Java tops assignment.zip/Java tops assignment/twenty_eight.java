
// • Write a program to print the area and perimeter of a triangle having sides of 3, 4 and
// 5 units by creating a class named 'Triangle' without any parameter in its constructor. 
import java.lang.Math;

class Triangle 
{
    private double side1;
    private double side2;
    private double side3;

    // Constructor without parameters
    Triangle() 
    {
        // Initialize sides with default values (3, 4, 5)
        side1 = 3;
        side2 = 4;
        side3 = 5;
    }

    // Method to calculate the perimeter
    public double calculatePerimeter() 
    {
        return side1 + side2 + side3;
    }

    // Method to calculate the area using Heron's formula
    public double calculateArea() 
    {
        double s = calculatePerimeter() / 2; // Semi-perimeter
        return Math.sqrt(s * (s - side1) * (s - side2) * (s - side3));
    }
}

public class twenty_eight 
{
    public static void main(String[] args) 
    {
        // Create an instance of the Triangle class
        Triangle triangle = new Triangle();

        // Calculate and print the perimeter and area
        double perimeter = triangle.calculatePerimeter();
        double area = triangle.calculateArea();

        System.out.println("Triangle with sides 3, 4, and 5 units:");
        System.out.println("Perimeter: " + perimeter + " units");
        System.out.println("Area: " + area + " square units");
    }
}
