// Create a class named 'Rectangle' with two data members 'length' and 'breadth' and
// two methods to print the area and perimeter of the rectangle respectively. Its
// constructor having parameters for length and breadth is used to initialize the length
// and breadth of the rectangle. Let class 'Square' inherit the 'Rectangle' class with its
// constructor having a parameter for its side (suppose s) calling the constructor of its
// parent class as 'super (s, s)'. Print the area and perimeter of a rectangle and a square. 
class rectangle 
{
    double length;
    double breadth;

    rectangle(double length, double breadth) 
    {
        this.length = length;
        this.breadth = breadth;

    }

    public void area() 
    {
        System.out.println("Area of rectangle: " + length * breadth);
    }

    public void perimeter() 
    {
        System.out.println("Perimeter of rectangle: " + 2 * (length + breadth));
    }

}

class square extends rectangle 
{

    square(double length, double breadth) 
    {
        super(length, breadth);
        // TODO Auto-generated constructor stub
    }

}

public class twenty_seven 
{
    public static void main(String[] args) 
    {
        square s = new square(5, 2);
        s.area();
        s.perimeter();

    }

}
