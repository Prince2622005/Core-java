// Create an abstract class 'Parent' with a method 'message'. It has two subclasses each
// having a method with the same name 'message' that prints "This is first subclass"
// and "This is second subclass" respectively. Call the methods 'message' by creating
// an object for each subclass.
abstract class parent 
{
    public abstract void message(); // abstarct method doesn't have bodies
}

class fsubclass extends parent 
{
    public void message() 
    {
        System.out.println("This is a First sub class");
    }
}

class ssubclass extends parent 
{
    public void message() 
    {
        System.out.println("This is second sub class");
    }
}

public class thirty 
{
    public static void main(String[] args) 
    {
        fsubclass f = new fsubclass();
        ssubclass s = new ssubclass();
        f.message();
        s.message();

    }
}