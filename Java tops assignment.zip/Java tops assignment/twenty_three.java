// Create a class to print an integer and a character with two methods having the same
// name but different sequence of the integer and the character parameters. For
// example, if the parameters of the first method are of the form (int n, char c), then
// that of the second method will be of the form (char c, int n). 
class same {
    public void print(int n, char c) // this is a method and methods have the body
    {
        System.out.println("int n: " + n);
        System.out.println("char c: " + c);
    }

    public void print(char c, int n) {
        System.out.println("char c: " + c);
        System.out.println("int n: " + n);
    }

}

public class twenty_three {
    public static void main(String[] args) {
        same s = new same();

        int integerNumber = 26;
        char character = 'P';

        s.print(integerNumber, character);
        s.print(character, integerNumber);

    }

}
