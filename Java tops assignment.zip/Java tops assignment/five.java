
// Write a program in Java to input 5 numbers from keyboard and find their sum and
// average using for loop
import java.util.Scanner;

public class five {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a, b, c, d, e;
        System.out.println("Input a: ");
        a = sc.nextInt();
        System.out.println("Input b: ");
        b = sc.nextInt();
        System.out.println("Input c: ");
        c = sc.nextInt();
        System.out.println("Input d: ");
        d = sc.nextInt();
        System.out.println("Input e: ");
        e = sc.nextInt();

        int sum;
        sum = a + b + c + d + e;
        System.out.println("Sum of values: " + sum);
        int avg;
        avg = sum / 5;
        System.out.println("Average: " + avg);

    }

}
