import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class twenty {

    public static char findSecondMostFrequentCharacter(String str) {
        if (str == null || str.isEmpty()) {
            throw new IllegalArgumentException("Input string is empty or null.");
        }

        // Create a frequency map to count characters in the string
        Map<Character, Integer> frequencyMap = new HashMap<>();

        for (char c : str.toCharArray()) {
            if (Character.isLetter(c)) { // Exclude non-letter characters if needed
                frequencyMap.put(c, frequencyMap.getOrDefault(c, 0) + 1);
            }
        }

        int maxFrequency = Integer.MIN_VALUE;
        int secondMaxFrequency = Integer.MIN_VALUE;
        char mostFrequentChar = '\0';
        char secondMostFrequentChar = '\0';

        // Find the most and second most frequent characters
        for (Entry<Character, Integer> entry : frequencyMap.entrySet()) {
            int frequency = entry.getValue();
            if (frequency > maxFrequency) {
                secondMaxFrequency = maxFrequency;
                maxFrequency = frequency;
                secondMostFrequentChar = mostFrequentChar;
                mostFrequentChar = entry.getKey();
            } else if (frequency > secondMaxFrequency && frequency < maxFrequency) {
                secondMaxFrequency = frequency;
                secondMostFrequentChar = entry.getKey();
            }
        }

        return secondMostFrequentChar;
    }

    public static void main(String[] args) {
        String inputString = "successes";
        char result = findSecondMostFrequentCharacter(inputString);

        System.out.println("The second most frequent char in the string is: " + result);
    }
}
