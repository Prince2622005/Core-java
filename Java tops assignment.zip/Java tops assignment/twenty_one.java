public class twenty_one 
{
    public static void main(String[] args) 
    {
        
        
    }
    
}
