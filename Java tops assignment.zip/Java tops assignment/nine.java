
// Write a Java program to count the letters, spaces, numbers and other characters of
// an input string
import java.util.Scanner;

public class nine {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string: ");
        String input = sc.nextLine();

        int lettercount = 0;
        int spacecount = 0;
        int numbercount = 0;
        int othercount = 0;

        for (char c : input.toCharArray()) {
            if (Character.isLetter(c)) {
                lettercount++;
            } else if (Character.isSpaceChar(c)) {
                spacecount++;
            } else if (Character.isDigit(c)) {
                numbercount++;
            } else {
                othercount++;
            }
        }
        System.out.println("Letter count: " + lettercount);
        System.out.println("Space count: " + spacecount);
        System.out.println("Number count: " + numbercount);
        System.out.println("Other count: " + othercount);
        sc.close();
    }
}
