class PrintNumber {
    public void printn(int num) {
        System.out.println("Printing an integer: " + num);
    }

    public void printn(double num) {
        System.out.println("Printing a double: " + num);
    }

    public void printn(String str) {
        System.out.println("Printing a string: " + str);
    }
}

public class twenty_two {
    public static void main(String[] args) {
        PrintNumber printer = new PrintNumber();

        int integerNumber = 42;
        double doubleNumber = 3.14;
        String stringData = "Hello, World!";

        printer.printn(integerNumber);
        printer.printn(doubleNumber);
        printer.printn(stringData);

    }

}
