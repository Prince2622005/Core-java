import java.util.Scanner;
import java.util.Date;

public class twelve {
    public static void main(String[] args) {
        Date date = new Date();
        System.out.println("System Time (using java.util.Date): " + date);
    }
}