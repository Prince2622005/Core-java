class Member {
    // Data members
    private String name;
    private int age;
    private String phoneNumber;
    private String address;
    private double salary;

    // Constructor to initialize the data members
    public Member(String name, int age, String phoneNumber, String address, double salary) {
        this.name = name;
        this.age = age;
        this.phoneNumber = phoneNumber;
        this.address = address;
        this.salary = salary;
    }

    // Method to print the salary of the member
    public void printSalary() {
        System.out.println("Salary of " + name + ": $" + salary);
    }

    // Getter methods for data members (optional)
    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public double getSalary() {
        return salary;
    }
}

public class twenty_six {
    public static void main(String[] args) {
        // Create an instance of the Member class
        Member member1 = new Member("John Doe", 30, "123-456-7890", "123 Main St", 50000.0);

        // Call the printSalary method to print the salary of the member
        member1.printSalary();
    }
}
