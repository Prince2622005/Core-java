import java.util.Scanner;

public class eight {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int number;
        number = sc.nextInt();
        if (number < 0) {
            System.out.println("Pls enter positive number");
        } else {
            int digitcount = countdigit(number);
            System.out.println("Total digit of number: " + digitcount);
        }
    }

    public static int countdigit(int number) {
        if (number == 0) {
            return 1;
        }
        int count = 0;
        while (number != 0) {
            number = number / 10;
            count++;

        }

        return count;
    }
}
