// Abstract class 'Bank'
abstract class Bank {
    // Abstract method 'getBalance'
    public abstract int getBalance();
}

// Subclass 'BankA' with its own 'getBalance' implementation
class BankA extends Bank {
    private int balance = 100; // Initial balance for BankA

    // @Override
    public int getBalance() {
        return balance;
    }
}

// Subclass 'BankB' with its own 'getBalance' implementation
class BankB extends Bank {
    private int balance = 150; // Initial balance for BankB

    @Override
    public int getBalance() {
        return balance;
    }
}

// Subclass 'BankC' with its own 'getBalance' implementation
class BankC extends Bank {
    private int balance = 200; // Initial balance for BankC

    @Override
    public int getBalance() {
        return balance;
    }
}

public class thirty_one {
    public static void main(String[] args) {
        // Create objects for each bank
        BankA bankA = new BankA();
        BankB bankB = new BankB();
        BankC bankC = new BankC();

        // Call 'getBalance' method for each bank and print the balance
        System.out.println("Balance in Bank A: $" + bankA.getBalance());
        System.out.println("Balance in Bank B: $" + bankB.getBalance());
        System.out.println("Balance in Bank C: $" + bankC.getBalance());
    }
}
